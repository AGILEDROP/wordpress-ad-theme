
import { __ } from '@wordpress/i18n';
import {
	registerBlockType,
} from '@wordpress/blocks';
import {
	RichText,
	MediaUpload,
} from '@wordpress/block-editor';
import { Button, RadioControl } from '@wordpress/components';
import { InspectorControls } from '@wordpress/editor';

registerBlockType( 'agiledrop/agiledrop-two-columns', {
	title: __( 'Agiledrop Two Columns', 'agiledrop-two-columns' ),
	icon: 'index-card',
	category: 'layout',
	attributes: {
		title: {
			type: 'array',
			source: 'children',
			selector: 'h2',
		},
		description: {
			type: 'array',
			source: 'children',
			selector: 'p',
		},
		mediaID: {
			type: 'number',
		},
		mediaURL: {
			type: 'string',
			source: 'attribute',
			selector: 'img',
			attribute: 'src',
		},
		positionOne: {
			default: 'agiledrop__left',
		},
		positionTwo: {
			default: 'agiledrop__right',
		}
	},
	edit: ( props ) => {
		const {
			attributes: {
				title,
				description,
				mediaID,
				mediaURL,
				positionOne,
				positionTwo,
			},
			setAttributes,
		} = props;
		const onChangeTitle = ( value ) => {
			setAttributes( { title: value } );
		};

		const onSelectImage = ( media ) => {
			setAttributes( {
				mediaURL: media.url,
				mediaID: media.id,
			} );
		};
		const onChangeDescription = ( value ) => {
			setAttributes( { description: value } );
		};

		const onChangeImagePosition = ( value ) => {
			if ( value === 'agiledrop__left') {
				setAttributes( { positionOne: 'agiledrop__left', positionTwo: 'agiledrop__right' } );
			}
			else {
				setAttributes( { positionOne: 'agiledrop__right', positionTwo: 'agiledrop__left' } );
			}
		}


		return (
			<div className="agiledrop">
				<InspectorControls>
					<RadioControl
						label={ __( 'Position Image', 'agiledrop-two-columns' ) }
						selected={ positionOne }
						options={ [
							{ label: 'Left', value: 'agiledrop__left' },
							{ label: 'Right', value: 'agiledrop__right' },
						] }
						onChange={ onChangeImagePosition }
					/>
				</InspectorControls>
				<div className={ positionTwo }>
					<RichText
						tagName="h2"
						placeholder={ __( 'Insert Title', 'agiledrop-two-columns' ) }
						value={ title }
						onChange={ onChangeTitle }
					/>
					<hr/>
					<RichText
						tagName="p"
						placeholder={ __( 'Insert Description', 'agiledrop-two-columns' ) }
						value={ description }
						onChange={ onChangeDescription }
					/>
				</div>
				<div className={ positionOne }>
					<MediaUpload
						onSelect={ onSelectImage }
						allowedTypes="image"
						value={ mediaID }
						render={ ( { open } ) => (
							<Button className={ mediaID ? 'image-button' : 'button button-large' } onClick={ open }>
								{ ! mediaID ? __( 'Upload Image', 'agiledrop-two-columns' ) : <img src={ mediaURL } alt={ __( 'Upload Image', 'agiledrop-two-columns' ) } /> }
							</Button>
						) }
					/>
				</div>
			</div>
		);
	},
	save: ( props ) => {
		const {
			attributes: {
				title,
				description,
				mediaURL,
				positionOne,
				positionTwo
			},
		} = props;
		return (
			<div className="agiledrop">
				<div className={ positionTwo }>
					<RichText.Content tagName="h2" value={ title } />
					<hr />
					<RichText.Content tagName="p" value={ description } />
				</div>
				<div className={ positionOne }>
					{
						mediaURL && (
							<img className="agiledrop__image" src={ mediaURL } alt={ __( 'Image', 'agiledrop-two-columns' ) } />
						)
					}
				</div>
			</div>
		);
	},
} );
