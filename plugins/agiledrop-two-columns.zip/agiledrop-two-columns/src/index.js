import { registerBlockType } from '@wordpress/blocks';

import * as image from './text-image';
import * as video from './text-video';

const blocks = [
	image,
	video,
];

function registerBlock( block ) {
	const { name, settings } = block;
	registerBlockType( name, settings );
}

blocks.forEach( registerBlock );