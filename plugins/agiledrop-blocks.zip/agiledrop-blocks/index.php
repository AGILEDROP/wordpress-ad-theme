<?php

/**
 * Plugin Name: AgiledropBlocks
 * Plugin URI: #
 * Description: Plugin that enables gutenberg block to show custom post types.
 * Version: 1.0.0
 * Author: Agiledrop
 *
 * @package agiledrop
 */

defined( 'ABSPATH' ) || exit;

/**
 * Load all translations for our plugin from the MO file.
 */

function agiledrop_load_textdomain() {
	load_plugin_textdomain( 'agiledrop', false, basename( __DIR__ ) . '/languages' );
}

add_action( 'init', 'agiledrop_load_textdomain' );


/**
 * Registers all block assets so that they can be enqueued through Gutenberg in
 * the corresponding context.
 *
 * Passes translations to JavaScript.
 */
function agiledrop_register_block() {

	// automatically load dependencies and version
	$asset_file = include( plugin_dir_path( __FILE__ ) . 'build/index.asset.php');

	wp_register_script(
		'agiledrop',
		plugins_url( 'build/index.js', __FILE__ ),
		$asset_file['dependencies'],
		$asset_file['version']
	);

	register_block_type( 'agiledrop-blocks/job-posts', array(
		'editor_script' => 'agiledrop',
	) );

	if ( function_exists( 'wp_set_script_translations' ) ) {
		/**
		 * May be extended to wp_set_script_translations( 'my-handle', 'my-domain',
		 * plugin_dir_path( MY_PLUGIN ) . 'languages' ) ). For details see
		 * https://make.wordpress.org/core/2018/11/09/new-javascript-i18n-support-in-wordpress/
		 */
		wp_set_script_translations( 'agiledrop', 'agiledrop' );
	}

}
add_action( 'init', 'agiledrop_register_block' );

function enqueue_wp_api() {
	wp_enqueue_script( 'wp-api' );
}
add_action( 'wp_enqueue_scripts', 'enqueue_wp_api' );