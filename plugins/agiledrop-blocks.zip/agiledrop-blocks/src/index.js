
import { __ } from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';
import { InspectorControls } from '@wordpress/editor';
import { SelectControl, CheckboxControl, RadioControl } from '@wordpress/components';
import { Component } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';

registerBlockType( 'agiledrop-blocks/job-posts', {
    title: __( 'Job Posts', 'agiledrop-blocks' ),
    icon: 'universal-access-alt',
    category: 'layout',
    attributes: {
        selectedColumn: {
            default: 1,
        },
        selectedPostType: {
            default: 'job-posts',
        },
        postTypes: [],
        executedTypes: {
            default: false
        },
        executedUpdate: {
            default: false
        },
        typeCheck: {
            default: ''
        },
        allPosts: [],
        selectedPosts: [],

    },


    edit: ( props ) => {

        const {
            attributes: {
                selectedColumn,
                selectedPostType,
                postTypes,
                executedTypes,
                executedUpdate,
                allPosts,
                typeCheck,
                selectedPosts,
            },
            setAttributes,
        } = props;

        const getPostTypes = () => {

                if ( !executedTypes ) {
                    apiFetch({path: '/agiledrop/v1/custom-post-types'}).then(types => {
                        if (types.length) {
                            let values = types.map(name => {
                                return {value: name, label: name}
                            });
                            setAttributes({postTypes: values})
                        }
                    });
                    setAttributes({executedTypes: true});
                }
        };

        getPostTypes();

        const getPosts = () => {
            if ( typeCheck !== selectedPostType ) {
                apiFetch({path: '/agiledrop/v1/' + selectedPostType}).then(posts => {
                    if (posts.length) {
                        let all = posts.map(post => {
                            return [{id: post.ID, title: post.post_title, checked: false}];
                        });
                        setAttributes({allPosts: all, selectedPosts: all });
                    }
                });
                setAttributes({typeCheck: selectedPostType})
            }
        };
        getPosts();
        const createCheck = () => {
            if ( allPosts !== undefined ) {
                let all = allPosts.map( post => {
                    return (
                        <CheckboxControl
                            label={ post[0].title }
                            checked={ post[0].checked }
                            onChange={ ( status ) => selectCheck( post[0].id, status ) }
                        />);
                } );
                return all;
            }
        };

        const selectCheck = ( postId, status  ) => {
            let a = allPosts.map( post => {
                if ( postId === post[0].id ) {
                   post[0].checked = status ;
                }
                return post;
            } );
            setAttributes( { allPosts: a, executedUpdate: false } )
        };

        const updateSelectedPosts = () => {
            if ( !executedUpdate ) {
                if ( allPosts !== undefined ) {
                    let newSelected = allPosts.map( post => {
                        if ( post[0].checked ) {
                            return post[0];
                        }
                    } );
                    newSelected = newSelected.filter( val => val );
                    setAttributes( {selectedPosts:  newSelected } );
                }
            }
            setAttributes( { executedUpdate: true } )
        };
        updateSelectedPosts();

        const selectColumn = ( value ) => {
            setAttributes( { selectedColumn: parseInt( value, 10) } )
        };

        const selectPostType = ( value ) => {
            setAttributes( { selectedPostType: value } );
        };


        const prepareColumns = () => {
            let columns = [];
            if ( selectedPosts !== undefined ) {
                selectedPosts.map( post => {
                    columns.push( <div className={"agiledrop-column column"}><h2>{ post.title}</h2></div> );
                } );

                let rows = [];
                if ( selectedColumn === 1 ) {
                    for( let i = 0; i < columns.length; i++) {
                        rows.push( <div className={"agiledrop-row row"}>{columns[i]}</div>);
                    }
                }
                if ( selectedColumn === 2 ) {
                    for( let i = 0; i < columns.length; i++) {
                        rows.push( <div className={"agiledrop-row row"}>{columns[i]} {columns[i+1]}</div>);
                        i++;
                    }
                }
                if ( selectedColumn === 3 ) {
                    for( let i = 0; i < columns.length; i++) {
                        rows.push( <div className={"agiledrop-row row"}>{columns[i]} {columns[i+1]} {columns[i+2]}</div>);
                        i+=2;
                    }
                }
                return ( rows );
            }
        };

        return ( [
            <InspectorControls>
                <RadioControl
                    label={ __( 'Select Columns' ) }
                    selected={ selectedColumn }
                    options={ [
                        { label: '1-column', value: 1 },
                        { label: '2-columns', value: 2 },
                        { label: '3-columns', value: 3 },
                    ] }
                    onChange={ selectColumn }
                />
                <SelectControl
                    label={ __( 'Select Post type' ) }
                    value={ selectedPostType }
                    options={ postTypes }
                    onChange={ selectPostType }
                />
                { createCheck() }
            </InspectorControls>,
            <div className={"agiledrop-block container"}>
                { prepareColumns() }
            </div>
            ]
        );
    },
    save: ( ) =>  {
        return null;
    }
} );
