
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
const { InspectorControls } = wp.editor;
const { SelectControl } = wp.components;
const { Component } = wp.element;
import apiFetch from '@wordpress/api-fetch';

class selectPostType extends Component {

    static getInitialState( selectedPostType ) {
        return {
            postTypes: [],
            selectedPostType: selectedPostType,
            postType: {},
        };
    }
    constructor() {
        super( ...arguments );
        // Maybe we have a previously selected post. Try to load it.
        this.state = this.constructor.getInitialState( this.props.attributes.selectedPostType );
        // Bind so we can use 'this' inside the method.
        this.getOptions = this.getOptions.bind(this);
        // Load posts.
        this.getOptions();
    }

    /**
     * Loading Posts
     */
    getOptions() {

        apiFetch( { path: '/agiledrop/v1/custom-post-types' } ).then( postTypes => {
            if ( postTypes.length) {

            }
            console.log( postTypes );
        } );
        /*return ( new wp.api.collections.Posts() ).fetch().then( ( postTypes ) => {
            if( postTypes && 0 !== this.state.selectedPostType ) {
                // If we have a selected Post, find that post and add it.
                const postType = postTypes.find( ( item ) => { return item.id == this.state.selectedPost } );
                // This is the same as { post: post, posts: posts }
                this.setState( { post, posts } );
            } else {
                this.setState({ posts });
            }
        });*/
    }

    render() {
        let options = [ { value: 0, label: __( 'Select Post Type', 'agiledrop' ) } ];
        let output  = __( 'Loading Post Types', 'agiledrop' );
        if( this.state.postTypes.length > 0 ) {
            this.state.postTypes.forEach((postType) => {
                options.push({value:postType.id, label:postType.title.rendered});
            });
        } else {
            output = __( 'No posts types found. Please create some first.' );
        }
        return [
            !! this.props.isSelected && ( <InspectorControls key='inspector'>
                    <SelectControl value={ this.props.attributes.selectedPostType } label={ __( 'Select Post Type' ) } options={ options } />
                </InspectorControls>
            ),
            output
        ]
    }

}

registerBlockType( 'agiledrop/job-posts', {
    title: __( 'Job Posts', 'agiledrop' ),
    icon: 'universal-access-alt',
    category: 'layout',

    attributes: {
        content: {
            type: 'array',
            source: 'children',
            selector: 'p',
        },
        title: {
            type: 'string',
            selector: 'h2'
        },
        link: {
            type: 'string',
            selector: 'a'
        },
        selectedPostType: {
            type: 'number',
            default: 0,
        },
    },
    edit:
        selectPostType,
    save() {
        return null;
    },
} );
