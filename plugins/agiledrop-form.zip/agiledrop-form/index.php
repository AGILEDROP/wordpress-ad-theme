<?php
/**
Plugin Name: Agiledrop Contact Form Plugin
Plugin URI: http://agiledrop.si
Description: Contact Form
Version: 1.0
Author: Agiledrop
Author URI: http://agiledrop.si
*/

add_action( 'wp_enqueue_scripts','agiledrop_form_script' );
function agiledrop_form_script() {
	wp_enqueue_script( 'agiledrop-form-js', plugins_url( '/agiledrop-form.js', __FILE__ ), array( 'jquery') );
}

add_action( 'wp_ajax_nopriv_agiledrop_save_form', 'agiledrop_form_save' );
add_action( 'wp_ajax_agiledrop_save_form', 'agiledrop_form_save' );

function agiledrop_form_save( $att ) {
    $name = wp_strip_all_tags( $_POST['name'] );
    $company = wp_strip_all_tags( $_POST['company'] );
    $email = wp_strip_all_tags( $_POST['email'] );
    $subject = wp_strip_all_tags( $_POST['subject'] );
    $message = wp_strip_all_tags( $_POST['message'] );

    return agiledrop_send_mail( $name, $company, $email, $subject, $message );

}

function agiledrop_send_mail( $name, $company, $email, $subject, $message ) {
    $to = get_bloginfo( 'admin_email' );
    $headers[] = 'From: ' . $name . '-' . $company .' <' . $to . '>';
    $headers[] = 'Replay-to: ' . $name . ' <' . $email .'>';
    return wp_mail( $to, $subject, $message, $headers );
}


function agiledrop_contact_form( ) {
	ob_start();?>
	<form id="agiledrop-form" action="#" method="post" data-url="<?php echo admin_url('admin-ajax.php'); ?>">
		<div class="form-group">
            <label for="name">Name</label>
			<input type="text" class="form-control" placeholder="Your Name" id="name" name="name" required>
            <p id="name-error"></p>
		</div>
		<div class="form-group">
            <label for="company">Company</label>
			<input type="text" class="form-control" placeholder="Your company" id="company" name="company" required>
            <p id="company-error"></p>
		</div>
		<div class="form-group">
            <label for="subject">Subject</label>
			<input type="text" class="form-control" placeholder="Subject" id="subject" name="subject" required>
            <p id="subject-error"></p>
		</div>
		<div class="form-group">
            <label for="email">Email</label>
			<input type="email" class="form-control" placeholder="Your email" id="email" name="email" required >
            <p id="email-error"></p>
		</div>
		<div class="form-group">
            <label for="message">Message</label>
			<textarea class="form-control" placeholder="Your message" id="message" name="message" required></textarea>
            <p id="message-error"></p>
		</div>
        <p id="form-status"></p>
		<button type="submit" class="btn btn-default">Submit</button>
	</form>
	<?php
	return ob_get_clean();
}
add_shortcode( 'agiledrop_contact_form', 'agiledrop_contact_form' );
